package learn.field_agent.domain;

import learn.field_agent.data.AliasRepository;
import learn.field_agent.models.Alias;
import learn.field_agent.models.SecurityClearance;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class AliasServiceTest {

    @Autowired
    AliasService aliasService;

    @MockBean
    AliasRepository aliasRepository;

    @Test
    void shouldAdd() {
        // Arrange
        Alias aliasIn = new Alias(0, "Ule", "Mantis", 1);
        Alias aliasOut = new Alias(1, "Ule", "Mantis", 2);

        // 4. Stub a specific behavior.
        when(aliasRepository.add(aliasIn)).thenReturn(aliasOut);

        // Act
        Result<Alias> result = aliasService.add(aliasIn);

        // Assert
        assertEquals(ResultType.SUCCESS, result.getType());
        assertEquals(aliasOut, result.getPayload());


    }



}
