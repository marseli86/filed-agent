package learn.field_agent.data;

import learn.field_agent.models.Alias;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class AliasJdbcTemplateRepositoryTest {

    @Autowired
    AliasJdbcTemplateRepository repository;

    @Autowired
    KnownGoodState knownGoodState;

    @BeforeEach
    void setup() {
        knownGoodState.set();
    }

    @Test
    void shouldFindAll() {
        List<Alias> aliases = repository.findAll();
        assertNotNull(aliases);
    }

    @Test
    void shouldAdd() {
        // all fields
        Alias aliases = makeAlias();
        Alias actual = repository.add(aliases);
        assertNotNull(actual);

    }

    private Alias makeAlias() {
        Alias alias = new Alias();
        alias.setAlias_id(1);
        alias.setName("Claudian");
        alias.setAgent_id(1);
        return alias;
    }




}
