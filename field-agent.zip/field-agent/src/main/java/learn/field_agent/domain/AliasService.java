package learn.field_agent.domain;


import learn.field_agent.data.AliasRepository;
import learn.field_agent.models.Alias;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class AliasService {
    private final AliasRepository aliasRepository;

    public AliasService(AliasRepository aliasRepository) {
        this.aliasRepository = aliasRepository;
    }


    public List<Alias> findAll() {

        return aliasRepository.findAll();
    }

    public Alias findById(int alias_id) {
        return aliasRepository.findById(alias_id);
    }


    public Result<Alias> add(Alias alias) {


        Result<Alias> result = validate(alias);
        if (!result.isSuccess()) {
            return result;
        }



        alias = aliasRepository.add(alias);
        result.setPayload(alias);


        return result;
    }


    private Result<Alias> validate(Alias alias) {
        List<Alias> alias1 = aliasRepository.findAllByName(alias.getName());
        Result<Alias> result = new Result<>();

        if (alias == null) {
            result.addMessage("alias cannot be null", ResultType.INVALID);
            return result;
        }

        if (Validations.isNullOrBlank(alias.getName())) {
            result.addMessage("Name is required", ResultType.INVALID);
        }
        if (Validations.isNullOrBlank(alias.getName())) {
            result.addMessage("Name is required", ResultType.INVALID);
        }
        if (!alias1.isEmpty() && alias1.stream()
                .anyMatch(x -> Objects.equals(x.getPersona(), alias.getPersona()))
        ) {
            result.addMessage("Please enter the persona or use different Persona", ResultType.INVALID);

        }

        return result;
    }

    public Result<Alias> update(Alias alias) {

        Result<Alias> result = validate(alias);
        if (!result.isSuccess()) {
            return result;
        }

        if (alias.getAlias_id() <= 0) {
            result.addMessage("alias must be set for `update` operation", ResultType.INVALID);
            return result;
        }

        if (!aliasRepository.update(alias)) {
            String msg = String.format("alias_id: %s, not found", alias.getAlias_id());
            result.addMessage(msg, ResultType.NOT_FOUND);
        }


        return result;
    }

    public boolean deleteById(int alias_id) {

        return aliasRepository.deleteById(alias_id);
    }

}
