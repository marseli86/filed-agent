package learn.field_agent.controllers;


import learn.field_agent.domain.AliasService;
import learn.field_agent.domain.Result;
import learn.field_agent.models.Alias;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = {"http://localhost:3000"})
@RequestMapping("/api/alias")
public class AliasController {

    private final AliasService aliasService;

    public AliasController(AliasService aliasService) {
        this.aliasService = aliasService;
    }
    @GetMapping
    public List<Alias> findAll() {

        return aliasService.findAll();
    }

    @GetMapping("/{alias_id}")
    public Alias findById(@PathVariable int alias_id)
    {
        return aliasService.findById(alias_id);
    }

    @PostMapping
    public ResponseEntity<Object> add(@RequestBody Alias alias) {
        Result<Alias> result = aliasService.add(alias);
        if (result.isSuccess()) {
            return new ResponseEntity<>(result.getPayload(), HttpStatus.CREATED);
        }
        return ErrorResponse.build(result);
    }
    @PutMapping("/{alias_id}")
    public ResponseEntity<Object> update(@PathVariable int alias_id, @RequestBody Alias alias) {
        if (alias_id != alias.getAlias_id()) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        Result<Alias> result = aliasService.update(alias);
        if (result.isSuccess()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        return ErrorResponse.build(result);
    }
    @DeleteMapping("/{alias_id}")
    public ResponseEntity<Object> deleteById(@PathVariable int alias_id) {

        if (aliasService.deleteById(alias_id)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
